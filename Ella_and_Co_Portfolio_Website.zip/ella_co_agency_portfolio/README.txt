ELLA & CO. AGENCY PORTFOLIO
===========================

Open index.html in a browser to preview the portfolio.

Included demos:
- projects/grand-arcade/feedback/index.html
- projects/district-27/site/index.html
- projects/carne-casa/index.html

To publish:
1. Upload the entire ella_co_agency_portfolio folder to Netlify Drop or deploy it as a site.
2. Keep the folder structure intact so project links and images work.
3. The Grand Arcade feedback form is a visual prototype and does not store submissions.
4. Carne Casa QR codes are placeholders. The page is an independent concept, not an official commission.
5. The portfolio currently uses a placeholder email address (hello@ellaandco.co.zw); replace it with the agency's preferred contact before public launch.
